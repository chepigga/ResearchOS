#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""FXArena GeoSweep v009 — frozen 24-cell geometry lab.
Control: C2 loop, TP1/120m/MICRO raw (no MinStop30).
Grid: TP {1,1.5,2,3} x timeout {120,360,720} x {MICRO>=30pt,H1_STRUCT>=30pt}.
Every grid cell retrains monthly WF LogisticRegression(C=.5) on its own y=(net_R>0).
"""
from __future__ import annotations
import os,sys,json,math,pickle,zipfile,hashlib,time,warnings,shutil
from pathlib import Path
import numpy as np,pandas as pd
from numba import njit,prange
from scipy.special import expit
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression

ROOT=Path('/mnt/data'); OUT=ROOT/'FXArena_GeoSweep_v009_output'; OUT.mkdir(exist_ok=True)
RPATH=ROOT/'FXArena_LevelBattleRounds_v003_EVENT_STREAM_EURUSD_M5(1).csv'
LPATH=ROOT/'FXArena_LevelBattleLevels_v003_EVENT_STREAM_EURUSD_M5(4).csv'
EPATH=ROOT/'FXArena_LevelBattleEvents_v003_EVENT_STREAM_EURUSD_M5(1).zip'
M1PATH=ROOT/'EURUSD_M1_202301020005_202607172354.csv.zip'
PPATH=ROOT/'C2_p_by_episode.csv'; WPATH=ROOT/'weights_schedule_C2.pkl'
PT=1e-5; COST_PTS=6.0
TPS=np.array([1.0,1.5,2.0,3.0],dtype=np.float64); TOS=np.array([120,360,720],dtype=np.int32)

RAW31=['micro_touch_number','structural_touch_number','micro_index_within_structural','is_new_structural_touch','level_age_hours','bars_since_previous_micro','bars_since_previous_structural','max_departure_previous_structural_atr','structural_reset_swing_confirmed','previous_micro_reaction_mfe_atr','previous_micro_reaction_mae_atr','previous_structural_reaction_atr','previous2_structural_reaction_atr','previous_structural_penetration_atr','previous2_structural_penetration_atr','approach_bars','approach_distance_atr','attack_path_atr','attack_net_progress_atr','attack_aligned_body_atr','attack_total_body_atr','attack_close_location','approach_tick_volume_mean','prior_tick_volume_mean','approach_range_mean_atr','prior_range_mean_atr','touch_open_rel_atr','touch_high_rel_atr','touch_low_rel_atr','touch_close_rel_atr','touch_spread_points']

def sha256(p):
 h=hashlib.sha256();
 with open(p,'rb') as f:
  for b in iter(lambda:f.read(1<<20),b''):h.update(b)
 return h.hexdigest()

def safe(a,b):
 a=np.asarray(a,float);b=np.asarray(b,float);return np.divide(a,b,out=np.zeros_like(a),where=np.abs(b)>1e-12)

def load_m1():
 with zipfile.ZipFile(M1PATH) as z:
  name=[n for n in z.namelist() if n.lower().endswith('.csv') and not n.startswith('__MACOSX')][0]
  with z.open(name) as f:d=pd.read_csv(f,sep='\t')
 d.columns=['date','time','o','h','l','c','tv','v','spr']
 dt=pd.to_datetime(d.date+' '+d.time,format='%Y.%m.%d %H:%M:%S',utc=True)
 T=(dt.astype('int64')//10**9).to_numpy(np.int64)
 return d,T,d.o.to_numpy(float),d.h.to_numpy(float),d.l.to_numpy(float),d.c.to_numpy(float),d.spr.to_numpy(np.int32)

def build_t_features(ids):
 with zipfile.ZipFile(EPATH) as z:
  name=[n for n in z.namelist() if n.lower().endswith('.csv') and not n.startswith('__MACOSX')][0]
  with z.open(name) as f:e=pd.read_csv(f,sep=';',usecols=['event_id','episode_id','event_time_unix','bar_offset','event_code','penetration_atr'])
 e=e[e.bar_offset<=2].sort_values(['episode_id','event_time_unix','event_id'])
 m=e[e.event_code.eq('MEANINGFUL_PENETRATION')].groupby('episode_id',sort=False).first()
 c=e[e.event_code.eq('FIRST_CLOSE_BEYOND')].groupby('episode_id',sort=False).first()
 non=e[~e.event_code.eq('TOUCH_START')].groupby('episode_id',sort=False).first()
 cnt=e.groupby('episode_id',sort=False).size()
 idx=e.groupby('episode_id',sort=False).penetration_atr.idxmax();mx=e.loc[idx].set_index('episode_id')
 t=pd.DataFrame(index=pd.Index(ids,name='episode_id'))
 t['t1']=m.bar_offset.reindex(t.index).fillna(-1).astype(float)
 t['t2']=c.bar_offset.reindex(t.index).fillna(-1).astype(float)
 t['t3']=m.bar_offset.reindex(t.index).notna().astype(float)
 t['t3b']=t.t1
 den=np.maximum(1,mx.bar_offset.reindex(t.index).fillna(0).to_numpy(float)+1)
 t['t4']=mx.penetration_atr.reindex(t.index).fillna(0).to_numpy(float)/den
 t['t5']=cnt.reindex(t.index).fillna(0).to_numpy(float)
 t['t6a']=(non.event_code.reindex(t.index)=='MEANINGFUL_PENETRATION').astype(float)
 t['t6b']=(non.event_code.reindex(t.index)=='FIRST_CLOSE_BEYOND').astype(float)
 return t

def build_features(r,obj):
 features=obj['features']; orig=r[['previous_structural_reaction_atr','previous2_structural_reaction_atr','previous_structural_penetration_atr','previous2_structural_penetration_atr']].copy()
 x=r[RAW31].fillna(0).copy()
 x['d1']=safe(x.attack_net_progress_atr,x.attack_path_atr)
 x['d3']=safe(x.attack_aligned_body_atr,x.attack_total_body_atr)
 x['d6']=np.log1p(safe(x.approach_tick_volume_mean,x.prior_tick_volume_mean))
 x['d7']=np.log1p(safe(x.approach_range_mean_atr,x.prior_range_mean_atr))
 both=orig.previous_structural_reaction_atr.notna()&orig.previous2_structural_reaction_atr.notna()
 x['d8']=np.where(both,np.clip(orig.previous_structural_reaction_atr-orig.previous2_structural_reaction_atr,-10,10),0)
 both=orig.previous_structural_penetration_atr.notna()&orig.previous2_structural_penetration_atr.notna()
 x['d9']=np.where(both,np.clip(orig.previous_structural_penetration_atr-orig.previous2_structural_penetration_atr,-10,10),0)
 x['d10']=safe(x.attack_net_progress_atr,x.approach_bars+1)
 x['d11']=1-np.abs(x.d1);x['d12']=x.attack_path_atr-np.abs(x.attack_net_progress_atr)
 t=build_t_features(r.episode_id.to_numpy());t=t.reindex(r.episode_id).reset_index(drop=True)
 for c in ['t1','t2','t3','t3b','t4','t5','t6a','t6b']:x[c]=t[c].to_numpy()
 return x[features].to_numpy(np.float64)

def h1_atr_from_m1(md):
 dt=pd.to_datetime(md.date+' '+md.time,format='%Y.%m.%d %H:%M:%S',utc=True)
 q=md.assign(dt=dt).set_index('dt').resample('1h',label='left',closed='left').agg(o=('o','first'),h=('h','max'),l=('l','min'),c=('c','last')).dropna()
 pc=q.c.shift(1);tr=np.maximum(q.h-q.l,np.maximum(abs(q.h-pc),abs(q.l-pc))).fillna(q.h-q.l)
 atr=tr.ewm(alpha=1/14,adjust=False).mean()
 return (q.index.astype('int64')//10**9).to_numpy(np.int64),atr.to_numpy(float)

def h1_risks(entry_t,entry,dirs,levels,h1T,h1ATR):
 lows=levels[levels.level_type.eq('H1_SWING_LOW')].sort_values('available_time_unix')
 highs=levels[levels.level_type.eq('H1_SWING_HIGH')].sort_values('available_time_unix')
 la=lows.available_time_unix.to_numpy(np.int64);lp=lows.price.to_numpy(float);le=lows.expiry_time_unix.to_numpy(np.int64)
 ha=highs.available_time_unix.to_numpy(np.int64);hp=highs.price.to_numpy(float);he=highs.expiry_time_unix.to_numpy(np.int64)
 out=np.full(len(entry),30*PT);fallback=np.zeros(len(entry),bool);swing=np.full(len(entry),np.nan);atrv=np.full(len(entry),np.nan)
 for i,(t,e,d) in enumerate(zip(entry_t,entry,dirs)):
  ai=np.searchsorted(h1T,(t//3600)*3600,side='left')-1
  av=h1ATR[max(0,ai)] if ai>=0 else np.nan;atrv[i]=av
  if not np.isfinite(av):fallback[i]=True;continue
  if d>0:
   k=np.searchsorted(la,t,side='right')-1;found=False
   for _ in range(64):
    if k<0:break
    if le[k]>=t and lp[k]<e:
     sd=e-(lp[k]-0.1*av);swing[i]=lp[k];found=True;break
    k-=1
  else:
   k=np.searchsorted(ha,t,side='right')-1;found=False
   for _ in range(64):
    if k<0:break
    if he[k]>=t and hp[k]>e:
     sd=(hp[k]+0.1*av)-e;swing[i]=hp[k];found=True;break
    k-=1
  if found and sd>0:out[i]=max(30*PT,sd)
  else:fallback[i]=True
 return out,fallback,swing,atrv

@njit(parallel=True,cache=True)
def replay_all(T,O,H,L,C,SPR,entry_t,entry_idx,dirs,entry,risk3):
 n=len(entry); ns=risk3.shape[1]; gross=np.empty((n,ns,4,3),np.float32);xt=np.empty((n,ns,4,3),np.int64);hold=np.empty((n,ns,4,3),np.float32);reason=np.empty((n,ns,4,3),np.int8)
 for i in prange(n):
  ei=entry_idx[i]
  for s in range(ns):
   r=risk3[i,s];sl=entry[i]-r if dirs[i]>0 else entry[i]+r
   tpidx=np.full(4,-1,np.int64);slidx=-1
   j=ei;end=entry_t[i]+720*60
   while j<len(T) and T[j]<end:
    sp=min(max(SPR[j],1),60)*PT
    slhit=(L[j]<=sl) if dirs[i]>0 else (H[j]+sp>=sl)
    if slhit:
     slidx=j;break
    for k in range(4):
     if tpidx[k]>=0:continue
     tp=entry[i]+TPS[k]*r if dirs[i]>0 else entry[i]-TPS[k]*r
     hit=(H[j]>=tp) if dirs[i]>0 else (L[j]+sp<=tp)
     if hit:tpidx[k]=j
    j+=1
   for k in range(4):
    for z in range(3):
     cutoff=entry_t[i]+TOS[z]*60
     if tpidx[k]>=0 and T[tpidx[k]]<cutoff and (slidx<0 or tpidx[k]<slidx):
      gross[i,s,k,z]=TPS[k];xt[i,s,k,z]=T[tpidx[k]];reason[i,s,k,z]=1
     elif slidx>=0 and T[slidx]<cutoff:
      gross[i,s,k,z]=-1.;xt[i,s,k,z]=T[slidx];reason[i,s,k,z]=-1
     else:
      jj=np.searchsorted(T,cutoff)
      if jj>=len(T):jj=len(T)-1
      sp=min(max(SPR[jj],1),60)*PT
      xp=C[jj]+(sp if dirs[i]<0 else 0.)
      g=(xp-entry[i])/r if dirs[i]>0 else (entry[i]-xp)/r
      gross[i,s,k,z]=g;xt[i,s,k,z]=T[jj];reason[i,s,k,z]=0
     hold[i,s,k,z]=(xt[i,s,k,z]-entry_t[i])/60.
 return gross,xt,hold,reason

def prep():
 t0=time.time();obj=pickle.load(open(WPATH,'rb'))
 cols=['episode_id','level_id','decision_3bar_time_unix','state_code','right_censored','max_penetration_atr','atr_touch']+RAW31
 rr=pd.read_csv(RPATH,sep=';',usecols=list(dict.fromkeys(cols)))
 r=rr[(rr.state_code!=0)&(rr.right_censored==0)].copy().reset_index(drop=True)
 levels=pd.read_csv(LPATH,sep=';'); dirs=r.merge(levels[['level_id','side']],on='level_id',how='left').side.to_numpy(np.int8)
 X=build_features(r,obj)
 md,T,O,H,L,C,SPR=load_m1();entry_t=r.decision_3bar_time_unix.to_numpy(np.int64)+60;ei=np.searchsorted(T,entry_t);sp=np.clip(SPR[np.minimum(ei,len(SPR)-1)],1,60)*PT;entry=O[np.minimum(ei,len(O)-1)]+np.where(dirs>0,sp,0)
 micro_raw=1.5*np.maximum(.75,r.max_penetration_atr.to_numpy(float))*r.atr_touch.to_numpy(float)
 micro30=np.maximum(micro_raw,30*PT)
 h1T,h1ATR=h1_atr_from_m1(md);h1,fallback,swing,atrv=h1_risks(entry_t,entry,dirs,levels,h1T,h1ATR)
 risk3=np.column_stack([micro_raw,micro30,h1])
 print('prep replay start',len(r),'fallback',fallback.mean(),flush=True)
 gross,xt,hold,reason=replay_all(T,O,H,L,C,SPR,entry_t,ei,dirs,entry,risk3)
 net=gross-COST_PTS*PT/risk3[:,:,None,None]
 np.save(OUT/'X48.npy',X.astype(np.float32));
 meta=r[['episode_id','level_id','decision_3bar_time_unix']].copy();meta['entry_t']=entry_t;meta['dir']=dirs;meta['entry']=entry;meta['micro_raw']=micro_raw;meta['micro30']=micro30;meta['h1risk']=h1;meta['h1fallback']=fallback;meta['h1swing']=swing;meta['h1atr']=atrv;meta.to_pickle(OUT/'meta.pkl')
 np.savez(OUT/'outcomes.npz',gross=gross,net=net.astype(np.float32),exit_t=xt,hold=hold,reason=reason)
 # full p parity
 p=pd.read_csv(PPATH,sep=';');mp=meta[['episode_id','decision_3bar_time_unix']].merge(p,on='episode_id');idxmap=pd.Series(np.arange(len(meta)),index=meta.episode_id).loc[mp.episode_id].to_numpy();Xp=X[idxmap]
 pred=np.full(len(mp),np.nan);sched={s[0]:s for s in obj['schedule']};months=pd.to_datetime(mp.decision_3bar_time_unix,unit='s').dt.to_period('M').astype(str)
 for mo,ii in months.groupby(months).groups.items():
  _,co,it,me,sc=sched[mo];jj=np.asarray(list(ii));pred[jj]=expit(it+((Xp[jj]-me)/sc)@co)
 diff=np.abs(pred-mp.p.to_numpy())
 audit={'n_universe':len(r),'p_parity_median':float(np.median(diff)),'p_parity_p99':float(np.quantile(diff,.99)),'p_parity_max':float(diff.max()),'h1_fallback_rate':float(fallback.mean()),'median_micro_raw_pts':float(np.median(micro_raw/PT)),'median_micro30_pts':float(np.median(micro30/PT)),'median_h1_pts':float(np.median(h1/PT)),'elapsed_sec':time.time()-t0}
 json.dump(audit,open(OUT/'prep_audit.json','w'),indent=2)
 print(json.dumps(audit,indent=2),flush=True)

def maxdd(x):
 eq=np.cumsum(x);peak=np.maximum.accumulate(np.r_[0.,eq]);return float(np.max(peak[1:]-eq))

def apply_risk(meta,pred,gross,net,xt,hold,top_frac=.04):
 z=meta.copy();z['p']=pred;z['gross']=gross;z['net']=net;z['exit_t']=xt;z['hold']=hold;z['month']=pd.to_datetime(z.decision_3bar_time_unix,unit='s').dt.to_period('M')
 cc=[]
 for mo,g in z[np.isfinite(z.p)].groupby('month',sort=True):
  k=int(math.ceil(top_frac*len(g)));cc.append(g.sort_values(['p','episode_id'],ascending=[False,True],kind='mergesort').head(k))
 cand=pd.concat(cc).sort_values(['entry_t','episode_id'],kind='mergesort').reset_index(drop=True)
 openp=[];rows=[];day_count={};consec=0;block=0
 for r in cand.itertuples(index=False):
  still=[]
  for q in openp:
   if q['exit_t']<=r.entry_t:
    if q['gross']<0:
     consec+=1
     if consec>=2:block=q['exit_t']+12*3600
    else:consec=0
   else:still.append(q)
  openp=still;day=r.entry_t//86400
  if day_count.get(day,0)>=6 or r.entry_t<block:continue
  q={'episode_id':r.episode_id,'level_id':r.level_id,'decision_3bar_time_unix':r.decision_3bar_time_unix,'entry_t':r.entry_t,'p':r.p,'gross':r.gross,'net':r.net,'exit_t':r.exit_t,'hold':r.hold}
  rows.append(q);openp.append(q);day_count[day]=day_count.get(day,0)+1
 return pd.DataFrame(rows)

def metrics(tr):
 if len(tr)==0:return {}
 tr=tr.sort_values(['entry_t','episode_id'],kind='mergesort').copy();tr['month']=pd.to_datetime(tr.entry_t,unit='s').dt.to_period('M');tr['year']=pd.to_datetime(tr.entry_t,unit='s').dt.year
 mo=tr.groupby('month').net.sum();yr=tr.groupby('year').agg(total_R=('net','sum'),EV=('net','mean'),N=('net','size'))
 wins=tr.net[tr.net>0].sum();loss=-tr.net[tr.net<0].sum()
 return {'total_R':float(tr.net.sum()),'EV':float(tr.net.mean()),'N':int(len(tr)),'WR':float((tr.net>0).mean()),'PF':float(wins/loss if loss>0 else np.inf),'MaxDD_gross_R':maxdd(tr.gross.to_numpy()),'MaxDD_net_R':maxdd(tr.net.to_numpy()),'negative_months':int((mo<0).sum()),'months':int(len(mo)),'worst_month_R':float(mo.min()),'median_hold_min':float(tr.hold.median()),'all_years_positive':bool((yr.total_R>0).all()),'yearly':{str(k):{'total_R':float(v.total_R),'EV':float(v.EV),'N':int(v.N)} for k,v in yr.iterrows()}}

def control():
 obj=pickle.load(open(WPATH,'rb'));meta=pd.read_pickle(OUT/'meta.pkl');o=np.load(OUT/'outcomes.npz');p=pd.read_csv(PPATH,sep=';');pred=meta.episode_id.map(p.set_index('episode_id').p).to_numpy()
 tr=apply_risk(meta,pred,o['gross'][:,0,0,0],o['net'][:,0,0,0],o['exit_t'][:,0,0,0],o['hold'][:,0,0,0]);m=metrics(tr)
 ref={'N':3716,'EV':.337,'MaxDD_gross_R':15.1,'negative_months':0};m['reference']=ref;m['pass_EV']=abs(m['EV']-.337)<=.01;m['pass_DD']=abs(m['MaxDD_gross_R']-15.1)<=.5;m['pass_N_tolerance']=abs(m['N']-3716)<=1;m['pass_negative_months']=m['negative_months']==0;m['verdict']='PASS' if all([m['pass_EV'],m['pass_DD'],m['pass_N_tolerance'],m['pass_negative_months']]) else 'STOP'
 tr.to_csv(OUT/'control_trades.csv.gz',index=False,compression='gzip');json.dump(m,open(OUT/'control_audit.json','w'),indent=2);print(json.dumps(m,indent=2),flush=True);return m

def fit_cell(stop_idx,tp_idx,to_idx):
 obj=pickle.load(open(WPATH,'rb'));features=obj['features'];X=np.load(OUT/'X48.npy',mmap_mode='r').astype(np.float64);meta=pd.read_pickle(OUT/'meta.pkl');o=np.load(OUT/'outcomes.npz',mmap_mode='r')
 net=np.asarray(o['net'][:,stop_idx,tp_idx,to_idx],float);gross=np.asarray(o['gross'][:,stop_idx,tp_idx,to_idx],float);xt=np.asarray(o['exit_t'][:,stop_idx,tp_idx,to_idx],np.int64);hold=np.asarray(o['hold'][:,stop_idx,tp_idx,to_idx],float)
 dec=meta.decision_3bar_time_unix.to_numpy(np.int64);months=pd.to_datetime(dec,unit='s').to_period('M').astype(str);pred=np.full(len(meta),np.nan)
 schedule_months=[s[0] for s in obj['schedule']]
 fitlog=[]
 for mo in schedule_months:
  start=int(pd.Period(mo).start_time.timestamp());tr=xt<start;te=months==mo
  if tr.sum()<1000 or te.sum()==0:continue
  sc=StandardScaler().fit(X[tr]);lr=LogisticRegression(C=.5,max_iter=500,solver='lbfgs',tol=1e-5).fit(sc.transform(X[tr]),(net[tr]>0).astype(np.int8));pred[te]=lr.predict_proba(sc.transform(X[te]))[:,1]
  fitlog.append((mo,int(tr.sum()),int(te.sum()),int(lr.n_iter_[0])))
 trades=apply_risk(meta,pred,gross,net,xt,hold);m=metrics(trades);m.update({'stop':['MICRO30','H1_STRUCT'][stop_idx-1],'tp_r':float(TPS[tp_idx]),'timeout_min':int(TOS[to_idx]),'cell_id':f"{['MICRO30','H1_STRUCT'][stop_idx-1]}_TP{TPS[tp_idx]:g}_TO{TOS[to_idx]}"})
 trades.to_csv(OUT/f"trades_{m['cell_id']}.csv.gz",index=False,compression='gzip');json.dump({'metrics':m,'fitlog':fitlog},open(OUT/f"cell_{m['cell_id']}.json",'w'),indent=2)
 print('DONE',m['cell_id'],m['N'],m['total_R'],m['EV'],m['MaxDD_gross_R'],flush=True)
 return m

def run_grid():
 c=control()
 if c['verdict']!='PASS':raise SystemExit('CONTROL STOP')
 rows=[]
 for s in [1,2]:
  for k in range(4):
   for z in range(3):rows.append(fit_cell(s,k,z))
 tab=pd.DataFrame([{k:v for k,v in r.items() if k!='yearly'} for r in rows]);base_total=c['total_R'];tab['GS1_total_gt_C2_10pct']=tab.total_R>base_total*1.10;tab['GS2_DD_le16']=tab.MaxDD_gross_R<=16;tab['GS3_months']=((tab.negative_months<=2)&(tab.worst_month_R>=-3));tab['GS4_years']=tab.all_years_positive;tab['candidate_GS1_GS4']=tab[['GS1_total_gt_C2_10pct','GS2_DD_le16','GS3_months','GS4_years']].all(axis=1)
 tab=tab.sort_values('total_R',ascending=False);tab.to_csv(OUT/'GeoSweep_v009_24cells.csv',index=False);json.dump(rows,open(OUT/'GeoSweep_v009_cells_full.json','w'),indent=2)
 print(tab.to_string(index=False),flush=True)

if __name__=='__main__':
 cmd=sys.argv[1] if len(sys.argv)>1 else 'run'
 {'prep':prep,'control':control,'grid':run_grid}[cmd]()
