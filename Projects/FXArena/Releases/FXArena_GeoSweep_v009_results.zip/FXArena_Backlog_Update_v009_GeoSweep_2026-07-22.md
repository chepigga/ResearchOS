# FXArena Backlog Update — v009 GeoSweep — 2026-07-22

## VERDICT

**GEO* = MICRO30 / TP2.0R / timeout 120m.**

Control PASS: N=3715, EV=+0.3334R, gross DD=14.99R, 0/42 negative.

GEO*: N=3544, total=+1856.4R, EV=+0.524R, PF=2.85, gross DD=14.42R, negative months=1/42, worst=-0.22R. Total uplift vs regenerated C2 control: +49.9%.

GS5 PASS: reverse/common total ratio=0.968, degradation=3.2%, reverse DD=15.59R.

GS6 PASS: permutation-200 EV p95=-0.202R vs real=+0.524R.

## CLOSED / FALSIFIED INSIDE v009

- Wider H1 structural stop is not GEO*: best H1 cell fails DD<=16R.
- Holding 6h/12h is not paid under the frozen DD constraint.
- TP3/2h raises total further but fails DD.

## NEXT

Run v010 TickFeatures/C3 strictly on GEO* geometry. ContPrimary v1.20 demo remains untouched.
