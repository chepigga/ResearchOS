#!/usr/bin/env python3
import os
os.environ.setdefault('OMP_NUM_THREADS','1');os.environ.setdefault('OPENBLAS_NUM_THREADS','1');os.environ.setdefault('MKL_NUM_THREADS','1');os.environ.setdefault('NUMEXPR_NUM_THREADS','1')
import sys,json,pickle,time
import numpy as np,pandas as pd
from joblib import Parallel,delayed,parallel_backend
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
sys.path.insert(0,'/mnt/data');import FXArena_GeoSweepLab_v009 as lab
OUT=lab.OUT
X=np.load(OUT/'X48.npy',mmap_mode='r');META=pd.read_pickle(OUT/'meta.pkl')
GROSS=np.load(OUT/'gross.npy',mmap_mode='r');NET=np.load(OUT/'net.npy',mmap_mode='r');EXIT=np.load(OUT/'exit_t.npy',mmap_mode='r');HOLD=np.load(OUT/'hold.npy',mmap_mode='r')
OBJ=pickle.load(open(lab.WPATH,'rb'));DEC=META.decision_3bar_time_unix.to_numpy(np.int64);MONTH=np.asarray(pd.to_datetime(DEC,unit='s').to_period('M').astype(str));MONTHS=[s[0] for s in OBJ['schedule']];CELLS=[(s,k,z) for s in [1,2] for k in range(4) for z in range(3)]
def fit_cell(ci):
 s,k,z=CELLS[ci];net=np.asarray(NET[:,s,k,z],np.float64);xt=np.asarray(EXIT[:,s,k,z],np.int64);pred=np.full(len(META),np.nan,np.float32);fl=[]
 for mo in MONTHS:
  start=int(pd.Period(mo).start_time.timestamp());tr=np.flatnonzero(xt<start);te=np.flatnonzero(MONTH==mo)
  if len(tr)<1000 or len(te)==0:continue
  Xtr=np.asarray(X[tr],np.float64);Xte=np.asarray(X[te],np.float64);sc=StandardScaler().fit(Xtr)
  lr=LogisticRegression(C=.5,max_iter=500,solver='lbfgs',tol=1e-4).fit(sc.transform(Xtr),(net[tr]>0).astype(np.int8));pred[te]=lr.predict_proba(sc.transform(Xte))[:,1];fl.append((mo,len(tr),len(te),int(lr.n_iter_[0])))
 return ci,pred,fl

def main(njobs=5):
 t0=time.time();print('CELLS',len(CELLS),'NJOBS',njobs,flush=True)
 with parallel_backend('loky',inner_max_num_threads=1):res=Parallel(n_jobs=njobs,verbose=10)(delayed(fit_cell)(ci) for ci in range(len(CELLS)))
 rows=[]
 for ci,pred,fl in res:
  s,k,z=CELLS[ci];gross=np.asarray(GROSS[:,s,k,z],float);net=np.asarray(NET[:,s,k,z],float);xt=np.asarray(EXIT[:,s,k,z],np.int64);hold=np.asarray(HOLD[:,s,k,z],float)
  tr=lab.apply_risk(META,pred,gross,net,xt,hold);m=lab.metrics(tr);m.update({'stop':['MICRO30','H1_STRUCT'][s-1],'tp_r':float(lab.TPS[k]),'timeout_min':int(lab.TOS[z]),'cell_id':f"{['MICRO30','H1_STRUCT'][s-1]}_TP{lab.TPS[k]:g}_TO{lab.TOS[z]}"});tr.to_csv(OUT/f"trades_{m['cell_id']}.csv.gz",index=False,compression='gzip');json.dump({'metrics':m,'fitlog':fl},open(OUT/f"cell_{m['cell_id']}.json",'w'),indent=2);rows.append(m);print('DONE',m['cell_id'],m['N'],round(m['total_R'],2),round(m['EV'],4),round(m['MaxDD_gross_R'],2),flush=True)
 c=json.load(open(OUT/'control_audit.json'));tab=pd.DataFrame([{kk:vv for kk,vv in r.items() if kk!='yearly'} for r in rows]);base=c['total_R'];tab['GS1_total_gt_C2_10pct']=tab.total_R>base*1.1;tab['GS2_DD_le16']=tab.MaxDD_gross_R<=16;tab['GS3_months']=(tab.negative_months<=2)&(tab.worst_month_R>=-3);tab['GS4_years']=tab.all_years_positive;tab['candidate_GS1_GS4']=tab[['GS1_total_gt_C2_10pct','GS2_DD_le16','GS3_months','GS4_years']].all(axis=1);tab=tab.sort_values('total_R',ascending=False);tab.to_csv(OUT/'GeoSweep_v009_24cells.csv',index=False);json.dump(rows,open(OUT/'GeoSweep_v009_cells_full.json','w'),indent=2);print('ELAPSED',time.time()-t0,flush=True);print(tab.to_string(index=False),flush=True)
if __name__=='__main__':main(int(sys.argv[1]) if len(sys.argv)>1 else 5)
