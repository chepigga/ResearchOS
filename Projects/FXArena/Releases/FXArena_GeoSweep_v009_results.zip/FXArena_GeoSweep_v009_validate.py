#!/usr/bin/env python3
import os
os.environ.setdefault('OMP_NUM_THREADS','1')
os.environ.setdefault('OPENBLAS_NUM_THREADS','1')
os.environ.setdefault('MKL_NUM_THREADS','1')
os.environ.setdefault('NUMEXPR_NUM_THREADS','1')
import json, pickle, time, math, sys
from pathlib import Path
import numpy as np
import pandas as pd
from joblib import Parallel, delayed, parallel_backend
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
sys.path.insert(0,'/mnt/data')
import FXArena_GeoSweepLab_v009 as lab

OUT=lab.OUT
X=np.load(OUT/'X48.npy',mmap_mode='r')
META=pd.read_pickle(OUT/'meta.pkl')
GROSS=np.load(OUT/'gross.npy',mmap_mode='r')
NET=np.load(OUT/'net.npy',mmap_mode='r')
EXIT=np.load(OUT/'exit_t.npy',mmap_mode='r')
HOLD=np.load(OUT/'hold.npy',mmap_mode='r')
OBJ=pickle.load(open(lab.WPATH,'rb'))
DEC=META.decision_3bar_time_unix.to_numpy(np.int64)
ENTRY=META.entry_t.to_numpy(np.int64)
EID=META.episode_id.to_numpy(np.int64)
MONTH_STR=np.asarray(pd.to_datetime(DEC,unit='s').to_period('M').astype(str))
MONTHS=[s[0] for s in OBJ['schedule']]
CANDS=[
    {'cell_id':'MICRO30_TP1.5_TO120','s':1,'k':1,'z':0},
    {'cell_id':'MICRO30_TP2_TO120','s':1,'k':2,'z':0},
]

def fit_predictions(c, mode):
    s,k,z=c['s'],c['k'],c['z']
    net=np.asarray(NET[:,s,k,z],np.float64)
    xt=np.asarray(EXIT[:,s,k,z],np.int64)
    pred=np.full(len(META),np.nan,np.float32)
    fitlog=[]
    for mo in MONTHS:
        te=np.flatnonzero(MONTH_STR==mo)
        if len(te)==0: continue
        per=pd.Period(mo)
        if mode=='forward':
            boundary=int(per.start_time.timestamp())
            tr=np.flatnonzero(xt<boundary)
        elif mode=='reverse':
            next_start=int((per+1).start_time.timestamp())
            tr=np.flatnonzero(DEC>=next_start)
        else: raise ValueError(mode)
        if len(tr)<1000: continue
        Xtr=np.asarray(X[tr],np.float64); Xte=np.asarray(X[te],np.float64)
        sc=StandardScaler().fit(Xtr)
        lr=LogisticRegression(C=.5,max_iter=500,solver='lbfgs',tol=1e-4)
        lr.fit(sc.transform(Xtr),(net[tr]>0).astype(np.int8))
        pred[te]=lr.predict_proba(sc.transform(Xte))[:,1].astype(np.float32)
        fitlog.append({'month':mo,'n_train':int(len(tr)),'n_test':int(len(te)),'n_iter':int(lr.n_iter_[0])})
    np.save(OUT/f"pred_{c['cell_id']}_{mode}.npy",pred)
    return c['cell_id'],mode,pred,fitlog

def exact_risk_numpy(sel_idx,gross,net,xt,hold):
    # Exact semantics of lab.apply_risk: selected indices are sorted by entry_t/eid;
    # open positions are resolved in entry order whenever their exit <= current entry.
    order=np.lexsort((EID[sel_idx],ENTRY[sel_idx]))
    ids=sel_idx[order]
    open_ids=[]; accepted=[]; day_count={}; consec=0; block=0
    for i in ids:
        t=int(ENTRY[i]); still=[]
        for q in open_ids:
            if int(xt[q])<=t:
                if float(gross[q])<0:
                    consec+=1
                    if consec>=2: block=int(xt[q])+12*3600
                else:
                    consec=0
            else:
                still.append(q)
        open_ids=still
        day=t//86400
        if day_count.get(day,0)>=6 or t<block:
            continue
        accepted.append(i); open_ids.append(i); day_count[day]=day_count.get(day,0)+1
    a=np.asarray(accepted,np.int64)
    if len(a)==0:
        return {'total_R':0.,'EV':np.nan,'N':0,'WR':np.nan,'PF':np.nan,'MaxDD_gross_R':np.nan}
    nv=net[a].astype(float); gv=gross[a].astype(float)
    wins=nv[nv>0].sum(); losses=-nv[nv<0].sum()
    return {
      'total_R':float(nv.sum()),'EV':float(nv.mean()),'N':int(len(a)),
      'WR':float((nv>0).mean()),'PF':float(wins/losses if losses>0 else np.inf),
      'MaxDD_gross_R':lab.maxdd(gv), 'accepted_idx':a
    }

def selection_indices_from_pred(pred, eligible_months=None):
    chunks=[]
    months=MONTHS if eligible_months is None else eligible_months
    for mo in months:
        idx=np.flatnonzero((MONTH_STR==mo)&np.isfinite(pred))
        if len(idx)==0: continue
        k=int(math.ceil(.04*len(idx)))
        # stable p desc / episode_id asc
        order=np.lexsort((EID[idx],-pred[idx]))
        chunks.append(idx[order[:k]])
    return np.concatenate(chunks) if chunks else np.empty(0,np.int64)

def validate_one(c, pred_f, pred_r, fit_f, fit_r, seed=20260722):
    s,k,z=c['s'],c['k'],c['z']
    gross=np.asarray(GROSS[:,s,k,z],float); net=np.asarray(NET[:,s,k,z],float)
    xt=np.asarray(EXIT[:,s,k,z],np.int64); hold=np.asarray(HOLD[:,s,k,z],float)
    # Full forward metrics (sanity against already saved grid)
    tr_f=lab.apply_risk(META,pred_f,gross,net,xt,hold)
    met_f=lab.metrics(tr_f)
    # Reverse common-month comparison: only months for which reverse prediction exists.
    rev_months=[mo for mo in MONTHS if np.isfinite(pred_r[MONTH_STR==mo]).any()]
    pred_f_common=pred_f.copy(); pred_f_common[~np.isin(MONTH_STR,rev_months)]=np.nan
    tr_fc=lab.apply_risk(META,pred_f_common,gross,net,xt,hold)
    tr_r=lab.apply_risk(META,pred_r,gross,net,xt,hold)
    met_fc=lab.metrics(tr_fc); met_r=lab.metrics(tr_r)
    ratio=float(met_r['total_R']/met_fc['total_R']) if met_fc['total_R'] else np.nan
    degradation=float(1-ratio)
    gs5=bool(ratio>=.80 and met_r['MaxDD_gross_R']<=16)

    # 200 monthly p shuffles: identical to random k-of-n selection per month.
    rng=np.random.default_rng(seed + int(100*c['k']) + int(c['z']))
    month_groups=[]
    for mo in MONTHS:
        idx=np.flatnonzero((MONTH_STR==mo)&np.isfinite(pred_f))
        if len(idx): month_groups.append((idx,int(math.ceil(.04*len(idx)))))
    null=[]
    for b in range(200):
        sel=np.concatenate([rng.choice(idx,size=kk,replace=False) for idx,kk in month_groups])
        mm=exact_risk_numpy(sel,gross,net,xt,hold)
        null.append({kk:mm[kk] for kk in ['total_R','EV','N','WR','PF','MaxDD_gross_R']})
    nd=pd.DataFrame(null)
    p95_ev=float(nd.EV.quantile(.95)); p95_total=float(nd.total_R.quantile(.95))
    gs6=bool(met_f['EV']>p95_ev)
    nd.to_csv(OUT/f"permutation200_{c['cell_id']}.csv",index=False)
    tr_r.to_csv(OUT/f"trades_revchrono_{c['cell_id']}.csv.gz",index=False,compression='gzip')
    result={
      'cell_id':c['cell_id'],
      'forward_full':met_f,
      'common_months':rev_months,
      'forward_common':met_fc,
      'reverse_chrono':met_r,
      'GS5_ratio_reverse_to_forward_common':ratio,
      'GS5_degradation':degradation,
      'GS5_DD_le16':bool(met_r['MaxDD_gross_R']<=16),
      'GS5_PASS':gs5,
      'permutation_200':{
        'seed':seed + int(100*c['k']) + int(c['z']),
        'EV_median':float(nd.EV.median()),'EV_p95':p95_ev,'EV_max':float(nd.EV.max()),
        'total_R_median':float(nd.total_R.median()),'total_R_p95':p95_total,'total_R_max':float(nd.total_R.max()),
        'DD_median':float(nd.MaxDD_gross_R.median()),'DD_p95':float(nd.MaxDD_gross_R.quantile(.95)),
      },
      'GS6_real_EV_gt_p95_null':bool(met_f['EV']>p95_ev),
      'GS6_real_total_gt_p95_null':bool(met_f['total_R']>p95_total),
      'GS6_PASS':gs6,
      'fitlog_forward':fit_f,'fitlog_reverse':fit_r,
    }
    json.dump(result,open(OUT/f"validation_{c['cell_id']}.json",'w'),indent=2)
    return result

def main():
    t0=time.time()
    jobs=[]
    for c in CANDS:
        jobs.extend([(c,'forward'),(c,'reverse')])
    with parallel_backend('loky',inner_max_num_threads=1):
        fitted=Parallel(n_jobs=4,verbose=10)(delayed(fit_predictions)(c,m) for c,m in jobs)
    D={(cid,mode):(pred,fl) for cid,mode,pred,fl in fitted}
    results=[]
    for c in CANDS:
        pf,ff=D[(c['cell_id'],'forward')]; pr,fr=D[(c['cell_id'],'reverse')]
        r=validate_one(c,pf,pr,ff,fr); results.append(r)
        print(c['cell_id'],'GS5',r['GS5_PASS'],'ratio',r['GS5_ratio_reverse_to_forward_common'],'revDD',r['reverse_chrono']['MaxDD_gross_R'],'GS6',r['GS6_PASS'],'realEV',r['forward_full']['EV'],'nullp95',r['permutation_200']['EV_p95'],flush=True)
    json.dump(results,open(OUT/'GeoSweep_v009_GS5_GS6.json','w'),indent=2)
    print('ELAPSED',time.time()-t0)
if __name__=='__main__': main()
